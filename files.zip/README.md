# ⚡ PremortemAI — Complete Setup Guide

Predictive health monitoring platform powered by Claude AI.

---

## 📁 Project Structure

```
premortem-ai/
├── frontend/
│   └── index.html          ← Complete frontend (single HTML file)
│
├── backend/
│   ├── server.js           ← Express API server
│   ├── package.json
│   ├── .env.example        ← Copy → .env and add API key
│   └── public/             ← (auto-created) backend serves frontend here
│
├── firebase.json           ← Firebase Hosting config
└── README.md
```

---

## 🚀 Quick Start (Local Dev)

### Step 1 — Install backend dependencies

```bash
cd backend
npm install
```

### Step 2 — Set up environment

```bash
cp .env.example .env
```

Open `.env` and set your Anthropic API key:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxx
PORT=3001
CORS_ORIGIN=*
```

Get your key at: https://console.anthropic.com/settings/keys

### Step 3 — Start the backend

```bash
npm start        # production
npm run dev      # hot-reload dev (uses nodemon)
```

You'll see:
```
╔════════════════════════════════════╗
║  ⚡  PremortemAI Backend  v1.1.0   ║
║  http://localhost:3001             ║
╠════════════════════════════════════╣
║  ANTHROPIC_API_KEY : ✓ set         ║
...
```

### Step 4 — Open the frontend

**Option A** — Open directly in browser (simplest):
```
frontend/index.html   ← double-click or drag into browser
```
The frontend auto-detects `localhost` and routes API calls to `http://localhost:3001`.

**Option B** — Serve from backend:
```bash
# Copy frontend into backend/public
cp frontend/index.html backend/public/index.html
# Then visit:
open http://localhost:3001
```

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET`  | `/api/ping` | Health check |
| `GET`  | `/api/health-data` | Live sensor readings (simulated with jitter) |
| `POST` | `/api/sensors` | Ingest IoT sensor data |
| `GET`  | `/api/alerts` | Active health alerts |
| `PATCH`| `/api/alerts/:id/dismiss` | Dismiss an alert |
| `POST` | `/api/risk-score` | Composite risk score calculation |
| `POST` | `/api/chat` | Claude AI health chat |
| `POST` | `/api/analyze-labs` | AI lab report interpretation |
| `POST` | `/api/analyze-voice` | Voice biomarker risk assessment |

### Example: AI Chat

```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role":"user","content":"What is my biggest health risk?"}
    ]
  }'
```

Response:
```json
{ "reply": "Based on your current signals, your biggest concern is..." }
```

### Example: Lab Analysis

```bash
curl -X POST http://localhost:3001/api/analyze-labs \
  -H "Content-Type: application/json" \
  -d '{
    "labData": { "hba1c": "6.2", "chol": "215", "sbp": "138" }
  }'
```

### Example: Sensor Ingestion (IoT)

```bash
curl -X POST http://localhost:3001/api/sensors \
  -H "Content-Type: application/json" \
  -d '{ "voiceStress": 82, "heartRate": 77, "sleepQuality": 25 }'
```

---

## 🔥 Deploy to Firebase (Frontend)

### Prerequisites
```bash
npm install -g firebase-tools
firebase login
```

### Deploy
```bash
# From project root
firebase deploy --only hosting
```

Your frontend will be live at `https://your-project.web.app`

> **Note:** After deploying, update the `API` variable in `frontend/index.html`
> to point to your live backend URL (Cloud Run, Railway, Render, etc.)

---

## ☁️ Deploy Backend to Cloud Run (Google)

### Build & deploy
```bash
cd backend

# Build Docker image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/premortem-ai-backend

# Deploy
gcloud run deploy premortem-ai-backend \
  --image gcr.io/YOUR_PROJECT_ID/premortem-ai-backend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars ANTHROPIC_API_KEY=your-key-here
```

### Dockerfile (Cloud Run)
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 8080
ENV PORT=8080
CMD ["node","server.js"]
```

---

## 🚂 Deploy Backend to Railway / Render (Easiest)

1. Push the `backend/` folder to a GitHub repo
2. Connect to [Railway](https://railway.app) or [Render](https://render.com)
3. Set environment variable: `ANTHROPIC_API_KEY=your-key`
4. Deploy — done ✓

---

## 🔧 Frontend ↔ Backend Connection

In `frontend/index.html`, find this line near the top of the `<script>`:

```js
const API = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? 'http://localhost:3001'
  : '';  // same-origin when co-deployed
```

**If your backend is on a different domain** (Cloud Run, Railway, etc.), change the second value:

```js
const API = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? 'http://localhost:3001'
  : 'https://premortem-ai-backend-abc123.a.run.app';  // ← your backend URL
```

---

## 📱 Features

| Feature | Status |
|---------|--------|
| Dashboard — 5-signal real-time risk scoring | ✅ |
| Live signal jitter simulation (3s updates) | ✅ |
| 7-day risk trend chart | ✅ |
| Signal radar chart | ✅ |
| Voice biomarker recording + analysis | ✅ |
| Lab report manual entry + AI interpretation | ✅ |
| File upload (PDF / image) | ✅ |
| Claude-powered AI health chat | ✅ |
| Multi-turn conversation history | ✅ |
| Smart alert center with dismiss | ✅ |
| Fallback analysis (no API key needed) | ✅ |
| IoT sensor ingestion endpoint | ✅ |

---

## ⚠️ Important Notes

- **No real patient data is stored** — all state is in-memory and resets on server restart
- For production: replace in-memory state with a proper database (PostgreSQL, Firestore, etc.)
- Voice recording requires HTTPS in production (browser MediaStream API requirement)
- This is a demo platform — not a certified medical device. Always recommend physician consultation.

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Vanilla HTML/CSS/JS (zero build step) |
| Charts | Chart.js v4 |
| Backend | Node.js 18+ · Express 4 |
| AI | Anthropic Claude claude-sonnet-4-5 |
| Hosting | Firebase Hosting (frontend) |
| API Deploy | Cloud Run / Railway / Render (backend) |
