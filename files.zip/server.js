/**
 * PremortemAI — Backend API Server
 * ─────────────────────────────────
 * Node.js · Express · @anthropic-ai/sdk
 *
 * Endpoints
 * ──────────
 * GET  /api/ping
 * GET  /api/health-data
 * POST /api/sensors
 * GET  /api/alerts
 * PATCH /api/alerts/:id/dismiss
 * POST /api/risk-score
 * POST /api/chat
 * POST /api/analyze-labs
 * POST /api/analyze-voice
 */

'use strict';

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const path       = require('path');
const Anthropic  = require('@anthropic-ai/sdk');

/* ─────────────────────────────────
   INIT
───────────────────────────────── */
const app  = express();
const PORT = process.env.PORT || 3001;

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

/* ─────────────────────────────────
   MIDDLEWARE
───────────────────────────────── */
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET','POST','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.use(express.json({ limit: '10mb' }));

// Serve frontend (static) from /public when same-origin
app.use(express.static(path.join(__dirname, 'public')));

/* ─────────────────────────────────
   SHARED STATE  (replace with DB)
───────────────────────────────── */
let health = {
  voiceStress:  78,
  heartRate:    72,
  bpSystolic:   128,
  bpDiastolic:  82,
  sleepQuality: 34,
  typingRhythm: 61,
  mobilityScore:84,
  riskScore:    67,
  updatedAt:    new Date().toISOString(),
};

let alerts = [
  { id:'a1', type:'critical', title:'Hypertensive Event — 67% Probability',
    body:'Combined signals: voice stress 78/100 + sleep deficit + elevated morning HR. Window: 48 hours.',
    source:'5-signal fusion', ts: Date.now() - 120000, dismissed:false },
  { id:'a2', type:'warning',  title:'REM Sleep Deficit — 3rd Consecutive Night',
    body:'Only 34% sleep quality detected. Chronic REM deficit linked to elevated cortisol and cardiovascular risk.',
    source:'Sleep sensor', ts: Date.now() - 21600000, dismissed:false },
  { id:'a3', type:'warning',  title:'Voice Stress Index Up 85% from Baseline',
    body:'Weekly trend: 42 → 78. Jitter at 3.2% (borderline). Possible sympathetic NS activation.',
    source:'Voice biomarker', ts: Date.now() - 3600000, dismissed:false },
  { id:'a4', type:'ok',       title:'Mobility Pattern — Normal',
    body:'Gait analysis normal. Step regularity 94%. No fall risk indicators.',
    source:'Mobility sensor', ts: Date.now() - 1800000, dismissed:false },
];

/* ─────────────────────────────────
   UTILS
───────────────────────────────── */
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const jit   = (v, d)      => clamp(v + (Math.random() - 0.5) * d, 0, 100);

function calcRisk({ voiceStress, heartRate, sleepQuality, typingRhythm, mobilityScore }) {
  const hrNorm  = clamp((heartRate - 60) / 40 * 100, 0, 100);
  return Math.round(clamp(
    voiceStress  * 0.30 +
    (100 - sleepQuality) * 0.25 +
    typingRhythm * 0.20 +
    hrNorm       * 0.15 +
    (100 - mobilityScore) * 0.10,
    0, 100
  ));
}

function buildSystemPrompt(h) {
  return `
You are PremortemAI, an evidence-based AI health assistant.

Current patient health signals (real-time):
• Composite Risk Score   : ${h.riskScore}/100 (${h.riskScore>70?'High':h.riskScore>50?'Elevated':'Normal'})
• Voice Stress Index     : ${h.voiceStress}/100 — jitter 3.2%, shimmer 0.28 (elevated)
• Heart Rate (rPPG)      : ${h.heartRate} bpm
• Blood Pressure (est.)  : ${h.bpSystolic}/${h.bpDiastolic} mmHg
• Sleep Quality          : ${h.sleepQuality}% — REM deficit (3rd consecutive night)
• Typing Rhythm          : ${h.typingRhythm}/100 — slight irregularity
• Mobility Score         : ${h.mobilityScore}/100 — normal gait pattern
• Active Alert           : Hypertensive event probability 67% within 48 hours

Rules:
- Be concise; use bullet points for recommendations.
- Always cite which signals inform your conclusions.
- Never diagnose — recommend physician consultation for serious concerns.
- If emergency symptoms are described, immediately direct to emergency services.
- Responses ≤ 300 words unless a doctor report is requested.
`.trim();
}

/* ─────────────────────────────────
   ROUTES
───────────────────────────────── */

// Ping
app.get('/api/ping', (_req, res) => {
  res.json({ ok: true, version: '1.1.0', ts: new Date().toISOString() });
});

// Live health data (with jitter simulation)
app.get('/api/health-data', (_req, res) => {
  health = {
    ...health,
    voiceStress:   jit(health.voiceStress, 3),
    heartRate:     clamp(health.heartRate + (Math.random()-.5)*2, 55, 105),
    sleepQuality:  jit(health.sleepQuality, 1.5),
    typingRhythm:  jit(health.typingRhythm, 2),
    mobilityScore: jit(health.mobilityScore, 1.5),
    updatedAt:     new Date().toISOString(),
  };
  health.riskScore = calcRisk(health);
  res.json(health);
});

// Ingest sensor data (IoT / webhooks)
app.post('/api/sensors', (req, res) => {
  const fields = ['voiceStress','heartRate','sleepQuality','typingRhythm','mobilityScore','bpSystolic','bpDiastolic'];
  fields.forEach(k => { if (req.body[k] !== undefined) health[k] = parseFloat(req.body[k]); });
  health.riskScore = calcRisk(health);
  health.updatedAt = new Date().toISOString();
  res.json({ ok:true, riskScore: health.riskScore });
});

// Alerts list
app.get('/api/alerts', (_req, res) => {
  res.json(alerts.filter(a => !a.dismissed));
});

// Dismiss alert
app.patch('/api/alerts/:id/dismiss', (req, res) => {
  const a = alerts.find(x => x.id === req.params.id);
  if (!a) return res.status(404).json({ error:'Alert not found' });
  a.dismissed = true;
  res.json({ ok:true });
});

// Composite risk score endpoint
app.post('/api/risk-score', (req, res) => {
  const { voiceStress, heartRate, sleepQuality, typingRhythm, mobilityScore } = req.body;
  if ([voiceStress,heartRate,sleepQuality,typingRhythm,mobilityScore].some(v=>v===undefined)) {
    return res.status(400).json({ error:'All 5 signals required' });
  }
  const score = calcRisk({ voiceStress, heartRate, sleepQuality, typingRhythm, mobilityScore });
  const risk  = score>70?'high':score>50?'elevated':score>30?'moderate':'low';
  const pred  = score>60 ? { condition:'Hypertensive event', probability: Math.round(score*.85), windowHours:48 } : null;
  res.json({ score, risk, prediction: pred, ts: new Date().toISOString() });
});

/* ── AI CHAT ── */
app.post('/api/chat', async (req, res) => {
  const { messages, context } = req.body;
  if (!Array.isArray(messages) || !messages.length)
    return res.status(400).json({ error:'messages[] required' });

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.json({ reply:'⚠ ANTHROPIC_API_KEY not configured. Add it to your .env file.' });
  }

  try {
    const response = await anthropic.messages.create({
      model:      'claude-sonnet-4-5',
      max_tokens: 700,
      system:     context || buildSystemPrompt(health),
      messages:   messages.slice(-12),
    });
    res.json({ reply: response.content[0]?.text || 'No response generated.', usage: response.usage });
  } catch (err) {
    console.error('[chat]', err.message);
    res.status(500).json({ error:'AI service error', detail: err.message });
  }
});

/* ── LAB ANALYSIS ── */
app.post('/api/analyze-labs', async (req, res) => {
  const { labData } = req.body;
  if (!labData) return res.status(400).json({ error:'labData required' });

  const { hba1c, chol, sbp, creat, hgb, tsh } = labData;
  const hasData = Object.values(labData).some(v => v && String(v).trim());
  if (!hasData) return res.status(400).json({ error:'At least one lab value required' });

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.json(localLabAnalysis(labData));
  }

  const prompt = `
You are a clinical AI. Analyze these lab values and respond with ONLY valid JSON (no markdown fences, no extra text):

HbA1c          : ${hba1c||'not provided'} %
Total Cholesterol: ${chol||'not provided'} mg/dL
Systolic BP    : ${sbp||'not provided'} mmHg
Creatinine     : ${creat||'not provided'} mg/dL
Hemoglobin     : ${hgb||'not provided'} g/dL
TSH            : ${tsh||'not provided'} mIU/L

Use ADA / ACC-AHA / clinical reference ranges.
Return exactly this structure:
{
  "results": [
    { "marker": "string", "value": "string with unit", "status": "normal|borderline|high|low", "note": "brief evidence-based note" }
  ],
  "summary": "1-2 sentence clinical summary",
  "risk": "low|moderate|high",
  "recommendations": ["brief actionable recommendation"]
}
Only include markers that have actual values.`.trim();

  try {
    const r = await anthropic.messages.create({
      model: 'claude-sonnet-4-5',
      max_tokens: 800,
      messages: [{ role:'user', content: prompt }],
    });
    const raw   = r.content[0]?.text || '{}';
    const clean = raw.replace(/```json|```/g,'').trim();
    res.json(JSON.parse(clean));
  } catch (err) {
    console.error('[labs]', err.message);
    res.json(localLabAnalysis(labData));   // graceful fallback
  }
});

/* ── VOICE BIOMARKER ANALYSIS ── */
app.post('/api/analyze-voice', async (req, res) => {
  const { pitch, energy, jitterPct, shimmer, stressIndex } = req.body;
  if (stressIndex === undefined) return res.status(400).json({ error:'stressIndex required' });

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.json(localVoiceAnalysis(stressIndex));
  }

  const prompt = `
Clinical AI voice biomarker assessment.
Pitch: ${pitch||'N/A'} Hz · Energy: ${energy||'N/A'} dB · Jitter: ${jitterPct||'N/A'}% · Shimmer: ${shimmer||'N/A'} · Stress Index: ${stressIndex}/100

Respond ONLY with valid JSON:
{
  "stressLevel": "low|moderate|high|critical",
  "interpretation": "2-3 sentence clinical interpretation",
  "indicators": ["finding 1", "finding 2"],
  "recommendation": "specific actionable recommendation"
}`.trim();

  try {
    const r = await anthropic.messages.create({
      model:'claude-sonnet-4-5', max_tokens:350,
      messages:[{ role:'user', content: prompt }]
    });
    const raw=r.content[0]?.text||'{}';
    res.json(JSON.parse(raw.replace(/```json|```/g,'').trim()));
  } catch (err) {
    console.error('[voice]', err.message);
    res.json(localVoiceAnalysis(stressIndex));
  }
});

/* ─────────────────────────────────
   FALLBACK ANALYSIS (no API key)
───────────────────────────────── */
function localLabAnalysis({ hba1c, chol, sbp, creat, hgb, tsh }) {
  const results = [];
  if (hba1c)  { const v=parseFloat(hba1c);  results.push({ marker:'HbA1c',           value:`${v}%`,      status:v<5.7?'normal':v<6.5?'borderline':'high',  note:v>=6.5?'Diabetic range — consult endocrinology':v>=5.7?'Pre-diabetic — lifestyle intervention':'Normal glycemic control' }); }
  if (chol)   { const v=parseFloat(chol);   results.push({ marker:'Total Cholesterol',value:`${v} mg/dL`, status:v<200?'normal':v<240?'borderline':'high',  note:v>=240?'High — dietary/statin review':'Within acceptable range' }); }
  if (sbp)    { const v=parseFloat(sbp);    results.push({ marker:'Systolic BP',      value:`${v} mmHg`,  status:v<120?'normal':v<140?'borderline':'high',  note:v>=140?'Hypertensive — monitor closely':v>=120?'Elevated':'Optimal' }); }
  if (creat)  { const v=parseFloat(creat);  results.push({ marker:'Creatinine',       value:`${v} mg/dL`, status:v<1.2?'normal':v<1.5?'borderline':'high',  note:v>=1.5?'Elevated — renal function check needed':'Normal kidney function' }); }
  if (hgb)    { const v=parseFloat(hgb);    results.push({ marker:'Hemoglobin',       value:`${v} g/dL`,  status:v>=12?'normal':v>=10?'borderline':'low',   note:v<12?'Anemia range — iron/B12 evaluation':'Normal' }); }
  if (tsh)    { const v=parseFloat(tsh);    results.push({ marker:'TSH',              value:`${v} mIU/L`, status:(v>=0.4&&v<=4.0)?'normal':'borderline',    note:v>4?'Possible hypothyroidism':v<0.4?'Possible hyperthyroidism':'Normal thyroid function' }); }
  const high  = results.filter(r=>r.status==='high').length;
  return { results, risk: high>=2?'high':high===1?'moderate':'low',
    summary: `${results.length} markers analyzed locally. ${high} value(s) outside normal range.`,
    recommendations: high>0 ? ['Review flagged values with your physician','Consider retesting in 3 months'] : ['All values appear within range — continue current health habits'] };
}

function localVoiceAnalysis(stressIndex) {
  const si = parseFloat(stressIndex);
  return {
    stressLevel: si>80?'critical':si>65?'high':si>45?'moderate':'low',
    interpretation: `Voice stress index at ${si}/100 suggests ${si>65?'elevated sympathetic nervous system activity, consistent with significant physiological or psychological stress':'moderate stress within the borderline range'}.`,
    indicators: ['Jitter at 3.2% indicates pitch irregularity', 'Shimmer elevation suggests amplitude variation'],
    recommendation: si>65 ? 'Consider stress management techniques; monitor for further escalation and consult a physician if sustained.' : 'Continue monitoring; voice biomarkers are in borderline range.',
  };
}

/* ─────────────────────────────────
   CATCH-ALL → serve frontend
───────────────────────────────── */
app.get('*', (_req, res) => {
  const idx = path.join(__dirname, 'public', 'index.html');
  res.sendFile(idx, err => {
    if (err) res.status(404).json({ error:'Not found' });
  });
});

/* ─────────────────────────────────
   START
───────────────────────────────── */
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════╗
║  ⚡  PremortemAI Backend  v1.1.0   ║
║  http://localhost:${PORT}             ║
╠════════════════════════════════════╣
║  ANTHROPIC_API_KEY : ${process.env.ANTHROPIC_API_KEY ? '✓ set' : '✗ missing — add to .env'}   
╠════════════════════════════════════╣
║  GET  /api/health-data             ║
║  POST /api/chat                    ║
║  POST /api/analyze-labs            ║
║  POST /api/analyze-voice           ║
║  GET  /api/alerts                  ║
║  POST /api/risk-score              ║
║  POST /api/sensors                 ║
╚════════════════════════════════════╝
`);
});

module.exports = app;
